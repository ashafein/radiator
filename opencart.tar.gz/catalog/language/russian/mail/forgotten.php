<?php
// Text
$_['text_subject']  = '%s - новый пароль';
$_['text_greeting'] = 'Новый пароль был запрошен от %s.';
$_['text_password'] = 'Ваш новый пароль:';
?>