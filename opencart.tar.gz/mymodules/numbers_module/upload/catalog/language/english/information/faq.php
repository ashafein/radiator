<?php
// Heading 
$_['heading_title']    = 'Frequently Asked Questions';

// Text
$_['text_faq']	       = 'FAQs';
$_['text_error']	   = 'FAQ Page Not Found!';
$_['text_description'] = '<p>Get answers to those commonly asked questions!</p>';

// Buttons
$_['button_faq']       = 'FAQs';
?>