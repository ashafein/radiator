﻿<?php
// Heading 
$_['heading_title']   = 'Новости / Блог - Новости';

// Text
$_['text_error']      = 'Отсутствие вестей - само по себе неплохая весть!';
$_['text_read_more']  = 'читать далее';
$_['text_date_added'] = 'Добавленно:';

// Buttons
$_['button_news']     = 'Последние новости';
?>
